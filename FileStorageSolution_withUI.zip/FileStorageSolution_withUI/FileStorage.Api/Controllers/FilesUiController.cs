using System.Security.Cryptography;
using FileStorage.Api.Data;
using FileStorage.Api.Models;
using FileStorage.Api.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FileStorage.Api.Controllers;

public class FilesUiController : Controller
{
    private readonly AppDbContext _db;
    private readonly PathService _path;

    public FilesUiController(AppDbContext db, PathService path)
    {
        _db = db;
        _path = path;
    }

    public async Task<IActionResult> Index()
    {
        var items = await _db.Files.AsNoTracking()
            .OrderByDescending(x => x.UploadedAtUtc)
            .ToListAsync();
        return View(items);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Upload(List<IFormFile> files)
    {
        if (files == null || files.Count == 0)
        {
            TempData["Err"] = "업로드된 파일이 없습니다.";
            return RedirectToAction(nameof(Index));
        }

        foreach (var file in files)
        {
            if (file.Length <= 0) continue;

            var id = Guid.NewGuid().ToString("N");
            var originalName = _path.SanitizeFileName(file.FileName);
            var savedPath = _path.ComposeSavedPath(id, originalName);

            await using (var target = System.IO.File.Create(savedPath))
            {
                await file.CopyToAsync(target);
            }

            string shaHex;
            await using (var fs = System.IO.File.OpenRead(savedPath))
            {
                using var sha = SHA256.Create();
                var hash = await sha.ComputeHashAsync(fs);
                shaHex = Convert.ToHexString(hash);
            }

            var entity = new FileItem
            {
                Id = id,
                OriginalName = originalName,
                SavedPath = savedPath,
                ContentType = file.ContentType ?? "application/octet-stream",
                Size = new FileInfo(savedPath).Length,
                UploadedAtUtc = DateTime.UtcNow,
                Sha256 = shaHex
            };
            _db.Files.Add(entity);
        }

        await _db.SaveChangesAsync();
        TempData["Msg"] = "업로드 완료";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(string id)
    {
        var item = await _db.Files.FirstOrDefaultAsync(x => x.Id == id);
        if (item != null)
        {
            if (System.IO.File.Exists(item.SavedPath))
                System.IO.File.Delete(item.SavedPath);
            _db.Files.Remove(item);
            await _db.SaveChangesAsync();
            TempData["Msg"] = "삭제 완료";
        }
        else
        {
            TempData["Err"] = "파일이 존재하지 않습니다.";
        }
        return RedirectToAction(nameof(Index));
    }
}
