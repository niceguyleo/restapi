using FileStorage.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace FileStorage.Api.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<FileItem> Files => Set<FileItem>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<FileItem>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.OriginalName).IsRequired().HasMaxLength(260);
            e.Property(x => x.SavedPath).IsRequired().HasMaxLength(520);
            e.Property(x => x.ContentType).IsRequired().HasMaxLength(120);
            e.Property(x => x.Size);
            e.Property(x => x.UploadedAtUtc);
            e.Property(x => x.Sha256).HasMaxLength(96);
            e.HasIndex(x => x.UploadedAtUtc);
        });
    }
}
