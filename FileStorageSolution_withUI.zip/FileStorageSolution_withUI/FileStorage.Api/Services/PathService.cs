using System.Text.RegularExpressions;

namespace FileStorage.Api.Services;

public class PathService
{
    private readonly IWebHostEnvironment _env;
    private readonly string _root;

    public PathService(IWebHostEnvironment env)
    {
        _env = env;
        _root = Path.Combine(_env.ContentRootPath, "App_Data", "uploads");
        Directory.CreateDirectory(_root);
    }

    public string GetStorageRoot() => _root;

    public string SanitizeFileName(string fileName)
    {
        var safe = Path.GetFileName(fileName);
        safe = Regex.Replace(safe, @"[^\w\.\-\s]", "_");
        return string.IsNullOrWhiteSpace(safe) ? "file" : safe;
    }

    public string ComposeSavedPath(string id, string originalName)
        => Path.Combine(_root, $"{id}_{originalName}");
}
