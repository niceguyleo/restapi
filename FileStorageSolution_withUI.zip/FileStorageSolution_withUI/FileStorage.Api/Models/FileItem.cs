using System.ComponentModel.DataAnnotations;

namespace FileStorage.Api.Models;

public class FileItem
{
    [Key]
    public string Id { get; set; } = Guid.NewGuid().ToString("N");

    [Required, MaxLength(260)]
    public string OriginalName { get; set; } = default!;

    [Required, MaxLength(520)]
    public string SavedPath { get; set; } = default!;

    [Required, MaxLength(120)]
    public string ContentType { get; set; } = "application/octet-stream";

    public long Size { get; set; }

    [Required]
    public DateTime UploadedAtUtc { get; set; } = DateTime.UtcNow;

    [MaxLength(96)]
    public string? Sha256 { get; set; }
}
