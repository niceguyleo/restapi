# FileStorageSolution (ASP.NET Core 8.0, Controllers + EF Core + SQLite)

자료실 업/다운로드가 가능한 Web API 템플릿입니다.

## 기능
- 업로드: `POST /api/files` (단일), `POST /api/files/batch` (다중)
- 목록: `GET /api/files`
- 다운로드: `GET /api/files/{id}` (HTTP Range 지원)
- 삭제: `DELETE /api/files/{id}`
- 저장소: `App_Data/uploads`
- 메타데이터: `SQLite` (`App_Data/app.db`)의 `Files` 테이블

## 실행 (VS2022)
1. 솔루션 열기: **FileStorageSolution.sln**
2. 패키지 복원 후 실행 (F5)
3. Swagger: http://localhost:5282/swagger

## EF Core (선택)
- 본 템플릿은 `EnsureCreated()`로 DB를 자동 생성합니다.
- 마이그레이션을 사용하려면:
  ```powershell
  # 패키지 관리자 콘솔 (Visual Studio)
  Add-Migration InitialCreate
  Update-Database
  ```

## 보안 팁
- 확장자 화이트리스트 적용
- `X-Content-Type-Options: nosniff` 헤더 추가
- JWT/Role 기반 접근제어 (컨트롤러에 [Authorize] 적용)

## cURL 예시
```bash
# 단일 업로드
curl -X POST http://localhost:5282/api/files -F "file=@./sample.pdf"

# 목록
curl http://localhost:5282/api/files

# 다운로드
curl -OJ http://localhost:5282/api/files/{id}

# 삭제
curl -X DELETE http://localhost:5282/api/files/{id}
```


---

## UI (MVC, Razor Views)
- 기본 경로: `/` 또는 `/FilesUi`
- 업로드 폼(다중 파일), 목록, 다운로드 버튼, 삭제 버튼 제공
- API와 동일한 DB/저장소 사용

### 실행 후 접근
- 홈(UI): http://localhost:5282/
- Swagger(API): http://localhost:5282/swagger
