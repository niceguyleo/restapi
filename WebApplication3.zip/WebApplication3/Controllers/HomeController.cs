using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult MyCalendar()
        {
            int[] week1 = { 1, 2, 3, 4, 5, 6, 7 };
            int[] week2 = { 8, 9, 10, 11, 12, 13, 14 };
            int[] week3 = { 15, 16, 17, 18, 19, 20, 21 };
            int[] week4 = { 22, 23, 24, 25, 26, 27, 28 };
            int[] week5 = { 29, 30, 31, 0, 0, 0, 0 };
            int[][] month = { week1, week2, week3, week4, week5 };
            ViewBag.data = month;
            return View();
        }

        public IActionResult MyCalendar2(int year, int month)
        {
            int[,] days = new int[6, 7];
            int[] spaces = { 3, 6, 6, 2, 4, 0, 2, 5, 1, 3, 6, 1 };
            int[] LastDays = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
            int day = 1;
            for (var i = spaces[month - 1]; i < 7; i++)
            {
                days[0, i] = day++;
            }
            for (var i = 1; i < 6; i++)
            {

                for (var j = 0; j < 7; j++)
                {
                    if (day <= LastDays[month - 1])
                    {
                        days[i, j] = day++;
                    }
                    else
                    {
                        days[i, j] = 0;
                    }

                }
            }
            ViewBag.data = days;
            return View();// "<h1>Hello! ASP.NET</h1>";
        }

        public IActionResult GetData()
        {
            return View();
        }


        public IActionResult PrintData(int year, int month)
        {
            string result = "";
            var first = (int)new DateOnly(year, month, 1).DayOfWeek;
            var dayInMonth = DateTime.DaysInMonth(year, month);
            //result = (int)first.DayOfWeek + ":" + dayInMonth.ToString();
            List<string> dayInfo = new List<string>();
            var monthInfo = new List<List<string>>();
            for(var i = 0; i < first; i++)
            {
                dayInfo.Add("");
            }
            for(var i = 0; i < dayInMonth; i++)
            {

                dayInfo.Add(Convert.ToString(i + 1));
                if ((first + (i + 1)) % 7 == 0)
                {
                    monthInfo.Add(dayInfo);
                    dayInfo = new List<string>();                   
                }
                
            }
            var length = dayInfo.Count;
            for (var i=0;i<7-length;i++)
            {
                dayInfo.Add("*");
            }
            monthInfo.Add(dayInfo);
            return View(monthInfo);
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
