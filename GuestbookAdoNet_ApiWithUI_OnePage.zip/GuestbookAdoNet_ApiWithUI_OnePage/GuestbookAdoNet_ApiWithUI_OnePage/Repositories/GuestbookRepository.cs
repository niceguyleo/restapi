using GuestbookAdoNet_ApiWithUI_OnePage.Data;
using GuestbookAdoNet_ApiWithUI_OnePage.Models;
using Microsoft.Data.Sqlite;

namespace GuestbookAdoNet_ApiWithUI_OnePage.Repositories
{
    public class GuestbookRepository
    {
        private readonly SqliteDb _db;
        public GuestbookRepository(SqliteDb db) => _db = db;

        public async Task<(IEnumerable<GuestbookEntry> items, int total)> GetAllAsync(int skip=0, int take=50)
        {
            var list = new List<GuestbookEntry>();
            using var conn = _db.GetConnection();
            await conn.OpenAsync();

            using var countCmd = conn.CreateCommand();
            countCmd.CommandText = "SELECT COUNT(*) FROM GuestbookEntries;";
            var total = Convert.ToInt32(await countCmd.ExecuteScalarAsync());

            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT Id, UserId, Name, Title, Content, CreatedAt
                                FROM GuestbookEntries
                                ORDER BY Id DESC
                                LIMIT @take OFFSET @skip;";
            cmd.Parameters.Add(new SqliteParameter("@take", take));
            cmd.Parameters.Add(new SqliteParameter("@skip", skip));
            using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                list.Add(new GuestbookEntry
                {
                    Id = reader.GetInt32(0),
                    UserId = reader.GetString(1),
                    Name = reader.GetString(2),
                    Title = reader.GetString(3),
                    Content = reader.GetString(4),
                    CreatedAt = DateTime.Parse(reader.GetString(5))
                });
            }
            return (list, total);
        }

        public async Task<GuestbookEntry?> GetByIdAsync(int id)
        {
            using var conn = _db.GetConnection();
            await conn.OpenAsync();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT Id, UserId, Name, Title, Content, CreatedAt FROM GuestbookEntries WHERE Id=@id;";
            cmd.Parameters.Add(new SqliteParameter("@id", id));
            using var reader = await cmd.ExecuteReaderAsync();
            if (await reader.ReadAsync())
            {
                return new GuestbookEntry
                {
                    Id = reader.GetInt32(0),
                    UserId = reader.GetString(1),
                    Name = reader.GetString(2),
                    Title = reader.GetString(3),
                    Content = reader.GetString(4),
                    CreatedAt = DateTime.Parse(reader.GetString(5))
                };
            }
            return null;
        }

        public async Task<int> CreateAsync(GuestbookEntry e)
        {
            using var conn = _db.GetConnection();
            await conn.OpenAsync();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"INSERT INTO GuestbookEntries (UserId, Name, Title, Content, CreatedAt)
VALUES (@userId, @name, @title, @content, @createdAt);
SELECT last_insert_rowid();";
            cmd.Parameters.Add(new SqliteParameter("@userId", e.UserId));
            cmd.Parameters.Add(new SqliteParameter("@name", e.Name));
            cmd.Parameters.Add(new SqliteParameter("@title", e.Title));
            cmd.Parameters.Add(new SqliteParameter("@content", e.Content));
            cmd.Parameters.Add(new SqliteParameter("@createdAt", e.CreatedAt.ToString("o")));
            var result = await cmd.ExecuteScalarAsync();
            return Convert.ToInt32(result);
        }

        public async Task<bool> UpdateAsync(GuestbookEntry e)
        {
            using var conn = _db.GetConnection();
            await conn.OpenAsync();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"UPDATE GuestbookEntries SET UserId=@userId, Name=@name, Title=@title, Content=@content WHERE Id=@id;";
            cmd.Parameters.Add(new SqliteParameter("@userId", e.UserId));
            cmd.Parameters.Add(new SqliteParameter("@name", e.Name));
            cmd.Parameters.Add(new SqliteParameter("@title", e.Title));
            cmd.Parameters.Add(new SqliteParameter("@content", e.Content));
            cmd.Parameters.Add(new SqliteParameter("@id", e.Id));
            var rows = await cmd.ExecuteNonQueryAsync();
            return rows > 0;
        }

        public async Task<bool> PatchAsync(int id, GuestbookPatchDto patch)
        {
            var updates = new List<string>();
            var parameters = new List<SqliteParameter>();
            if (patch.UserId is not null) { updates.Add("UserId=@userId"); parameters.Add(new SqliteParameter("@userId", patch.UserId)); }
            if (patch.Name  is not null) { updates.Add("Name=@name"); parameters.Add(new SqliteParameter("@name", patch.Name)); }
            if (patch.Title is not null) { updates.Add("Title=@title"); parameters.Add(new SqliteParameter("@title", patch.Title)); }
            if (patch.Content is not null) { updates.Add("Content=@content"); parameters.Add(new SqliteParameter("@content", patch.Content)); }

            if (updates.Count == 0) return false;

            using var conn = _db.GetConnection();
            await conn.OpenAsync();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = $"UPDATE GuestbookEntries SET {string.Join(", ", updates)} WHERE Id=@id;";
            cmd.Parameters.AddRange(parameters.ToArray());
            cmd.Parameters.Add(new SqliteParameter("@id", id));
            var rows = await cmd.ExecuteNonQueryAsync();
            return rows > 0;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            using var conn = _db.GetConnection();
            await conn.OpenAsync();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "DELETE FROM GuestbookEntries WHERE Id=@id;";
            cmd.Parameters.Add(new SqliteParameter("@id", id));
            var rows = await cmd.ExecuteNonQueryAsync();
            return rows > 0;
        }
    }
}