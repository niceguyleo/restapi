using Microsoft.AspNetCore.Mvc;
using GuestbookAdoNet_ApiWithUI_OnePage.Repositories;
using GuestbookAdoNet_ApiWithUI_OnePage.Models;

namespace GuestbookAdoNet_ApiWithUI_OnePage.Controllers.Api
{
    [ApiController]
    [Route("api/[controller]")]
    public class GuestbookController : ControllerBase
    {
        private readonly GuestbookRepository _repo;
        public GuestbookController(GuestbookAdoNet_ApiWithUI_OnePage.Data.SqliteDb db)
        {
            _repo = new GuestbookRepository(db);
        }

        [HttpGet]
        public async Task<ActionResult<object>> GetAll([FromQuery] int skip = 0, [FromQuery] int take = 50)
        {
            var (items, total) = await _repo.GetAllAsync(skip, take);
            return Ok(new { total, skip, take, items });
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<GuestbookEntry>> GetById(int id)
        {
            var item = await _repo.GetByIdAsync(id);
            if (item is null) return NotFound();
            return Ok(item);
        }

        [HttpPost]
        public async Task<ActionResult<GuestbookEntry>> Create([FromBody] GuestbookCreateDto dto)
        {
            if (!ModelState.IsValid) return ValidationProblem(ModelState);
            var entity = new GuestbookEntry
            {
                UserId = dto.UserId,
                Name = dto.Name,
                Title = dto.Title,
                Content = dto.Content,
                CreatedAt = DateTime.UtcNow
            };
            var id = await _repo.CreateAsync(entity);
            entity.Id = id;
            return CreatedAtAction(nameof(GetById), new { id }, entity);
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] GuestbookUpdateDto dto)
        {
            if (!ModelState.IsValid) return ValidationProblem(ModelState);
            var existed = await _repo.GetByIdAsync(id);
            if (existed is null) return NotFound();
            existed.UserId = dto.UserId;
            existed.Name = dto.Name;
            existed.Title = dto.Title;
            existed.Content = dto.Content;
            var ok = await _repo.UpdateAsync(existed);
            if (!ok) return NotFound();
            return NoContent();
        }

        [HttpPatch("{id:int}")]
        public async Task<IActionResult> Patch(int id, [FromBody] GuestbookPatchDto dto)
        {
            var existed = await _repo.GetByIdAsync(id);
            if (existed is null) return NotFound();
            var ok = await _repo.PatchAsync(id, dto);
            if (!ok) return BadRequest(new { message = "No valid fields provided to update." });
            return NoContent();
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var existed = await _repo.GetByIdAsync(id);
            if (existed is null) return NotFound();
            var ok = await _repo.DeleteAsync(id);
            if (!ok) return NotFound();
            return NoContent();
        }
    }
}