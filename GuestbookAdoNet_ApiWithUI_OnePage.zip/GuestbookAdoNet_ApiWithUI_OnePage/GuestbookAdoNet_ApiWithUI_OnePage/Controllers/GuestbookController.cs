using Microsoft.AspNetCore.Mvc;

namespace GuestbookAdoNet_ApiWithUI_OnePage.Controllers
{
    public class GuestbookController : Controller
    {
        public IActionResult OnePage()
        {
            return View();
        }
    }
}