using Microsoft.Data.Sqlite;
using System.IO;

namespace GuestbookAdoNet_ApiWithUI_OnePage.Data
{
    public class SqliteDb
    {
        private readonly string _connectionString;
        public SqliteDb(string connectionString)
        {
            _connectionString = connectionString;
            var dataSource = new SqliteConnectionStringBuilder(connectionString).DataSource;
            var dir = Path.GetDirectoryName(dataSource);
            if (!string.IsNullOrWhiteSpace(dir) && !Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir!);
            }
        }

        public SqliteConnection GetConnection() => new SqliteConnection(_connectionString);

        public void Initialize()
        {
            using var conn = GetConnection();
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
CREATE TABLE IF NOT EXISTS GuestbookEntries (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    UserId TEXT NOT NULL,
    Name TEXT NOT NULL,
    Title TEXT NOT NULL,
    Content TEXT NOT NULL,
    CreatedAt TEXT NOT NULL
);";
            cmd.ExecuteNonQuery();
        }
    }
}