using System.ComponentModel.DataAnnotations;

namespace GuestbookAdoNet_ApiWithUI_OnePage.Models
{
    public class GuestbookEntry
    {
        public int Id { get; set; }
        [Required] public string UserId { get; set; } = string.Empty;
        [Required] public string Name { get; set; } = string.Empty;
        [Required] public string Title { get; set; } = string.Empty;
        [Required] public string Content { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    public class GuestbookCreateDto
    {
        [Required] public string UserId { get; set; } = string.Empty;
        [Required] public string Name { get; set; } = string.Empty;
        [Required] public string Title { get; set; } = string.Empty;
        [Required] public string Content { get; set; } = string.Empty;
    }

    public class GuestbookUpdateDto
    {
        [Required] public string UserId { get; set; } = string.Empty;
        [Required] public string Name { get; set; } = string.Empty;
        [Required] public string Title { get; set; } = string.Empty;
        [Required] public string Content { get; set; } = string.Empty;
    }

    public class GuestbookPatchDto
    {
        public string? UserId { get; set; }
        public string? Name { get; set; }
        public string? Title { get; set; }
        public string? Content { get; set; }
    }
}