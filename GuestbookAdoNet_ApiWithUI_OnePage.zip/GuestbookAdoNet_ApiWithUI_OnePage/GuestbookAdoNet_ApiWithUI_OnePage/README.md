# GuestbookAdoNet_ApiWithUI_OnePage (.NET 8, ADO.NET + SQLite)

- EF Core 없이 **ADO.NET**(`Microsoft.Data.Sqlite`)으로 구현
- **REST API**(`/api/guestbook`)와 **단일 페이지(One-Page) UI** 포함
- 기본 라우트: `/Guestbook/OnePage`
- 개발환경 Swagger: `/swagger`

실행: 솔루션 열기 → 실행(F5)