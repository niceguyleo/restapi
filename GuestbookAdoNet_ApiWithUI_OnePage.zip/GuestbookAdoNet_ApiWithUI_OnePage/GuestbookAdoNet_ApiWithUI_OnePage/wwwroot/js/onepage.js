(async function(){
  const api = (path, opt={}) => fetch((window.GUESTBOOK_API_BASE||'') + path, Object.assign({headers:{'Content-Type':'application/json'}}, opt));

  const tbody = document.getElementById('tbody');
  const rowTpl = document.getElementById('row-template');

  async function load(){
    tbody.innerHTML = '';
    const res = await api('/api/guestbook?skip=0&take=500');
    if(!res.ok){ alert('목록 조회 실패'); return; }
    const data = await res.json();
    (data.items||[]).forEach(item => addRow(item));
  }

  function addRow(item){
    const frag = rowTpl.content.cloneNode(true);
    const tr = frag.querySelector('tr');
    tr.dataset.id = item.id;
    tr.querySelector('.col-id').textContent = item.id;
    tr.querySelector('.col-userId').value = item.userId;
    tr.querySelector('.col-name').value = item.name;
    tr.querySelector('.col-title').value = item.title;
    tr.querySelector('.col-created').textContent = item.createdAt;

    tr.querySelector('.btn-save').addEventListener('click', async () => {
      const body = JSON.stringify({
        userId: tr.querySelector('.col-userId').value,
        name: tr.querySelector('.col-name').value,
        title: tr.querySelector('.col-title').value,
        content: item.content || ''
      });
      const res = await api(`/api/guestbook/${item.id}`, { method:'PUT', body });
      if(res.ok){ await load(); } else { alert('수정 실패'); }
    });

    tr.querySelector('.btn-delete').addEventListener('click', async () => {
      if(!confirm('삭제하시겠습니까?')) return;
      const res = await api(`/api/guestbook/${item.id}`, { method:'DELETE' });
      if(res.ok){ tr.remove(); } else { alert('삭제 실패'); }
    });

    tbody.appendChild(frag);
  }

  document.getElementById('btnCreate').addEventListener('click', async () => {
    const body = JSON.stringify({
      userId: document.getElementById('userId').value,
      name: document.getElementById('name').value,
      title: document.getElementById('title').value,
      content: document.getElementById('content').value
    });
    const res = await api('/api/guestbook', { method:'POST', body });
    if(res.ok){ 
      document.getElementById('userId').value='';
      document.getElementById('name').value='';
      document.getElementById('title').value='';
      document.getElementById('content').value='';
      await load(); 
    } else {
      alert('저장 실패');
    }
  });

  await load();
})();