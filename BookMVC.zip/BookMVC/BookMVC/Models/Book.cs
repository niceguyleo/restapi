﻿namespace BookMVC.Models
{
    public class Book
    {
        public string? author { get; set; }

        public string? title { get; set; }

        public string? publish_date { get; set; }
    }
}
