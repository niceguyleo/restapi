﻿namespace BookMVC.Models
{
    public class Author
    {
        public string? AuthorName { get; set; }
        public string? BookTitle { get; set; }

        public string? PublishDate { get; set; }
    }
}
