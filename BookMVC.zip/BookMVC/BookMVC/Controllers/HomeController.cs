using BookMVC.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections;
using System.Diagnostics;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace BookMVC.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IWebHostEnvironment _webHostEnvironment;
        public HomeController(ILogger<HomeController> logger, IWebHostEnvironment webHostEnvironment)
        {
            _logger = logger;
            _webHostEnvironment = webHostEnvironment;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult AuthorList()
        {
            string path = Path.Combine(_webHostEnvironment.ContentRootPath, "books.json");

            string jsonStr = System.IO.File.ReadAllText(path);
            
            List<Book>? list = JsonSerializer.Deserialize<List<Book>>(jsonStr);
            ViewData["json"] = jsonStr;
            return View(list);
        }

        public IActionResult AuthorsList()
        {
            string path = Path.Combine(_webHostEnvironment.ContentRootPath, "books.json");

            string jsonStr = System.IO.File.ReadAllText(path);

            List<Book>? list = JsonSerializer.Deserialize<List<Book>>(jsonStr);
            ViewData["json"] = jsonStr;
            return View(list);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
