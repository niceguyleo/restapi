using Microsoft.AspNetCore.Mvc;

namespace JwtMvcDemo.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index() => View();
    }
}
