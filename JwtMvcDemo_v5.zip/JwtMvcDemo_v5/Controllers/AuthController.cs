using JwtMvcDemo.Data;
using JwtMvcDemo.Models;
using JwtMvcDemo.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace JwtMvcDemo.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly ITokenService _tokenService;
        private readonly AppDbContext _db;
        public AuthController(ITokenService tokenService, AppDbContext db)
        {
            _tokenService = tokenService; _db = db;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest req)
        {
            var user = await _db.Users.AsNoTracking()
                .FirstOrDefaultAsync(u => u.UserName == req.UserName && u.Password == req.Password);
            if (user is null) return Unauthorized(new { message = "Invalid credentials" });

            var permissions = string.IsNullOrWhiteSpace(user.PermissionsCsv)
                ? Enumerable.Empty<string>()
                : user.PermissionsCsv.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

            var token = _tokenService.CreateAccessToken(user.Id, user.Name, user.Role, permissions);
            return Ok(new { accessToken = token.Token, expiresAt = token.ExpiresAt });
        }
    }
}
