using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace JwtMvcDemo.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class UsersController : ControllerBase
    {
        [HttpGet("me")]
        public IActionResult Me()
        {
            var user = HttpContext.User;
            var userId = user.FindFirstValue(ClaimTypes.NameIdentifier) ?? user.FindFirstValue("sub");
            var name   = user.FindFirstValue(ClaimTypes.Name);
            var role   = user.FindFirstValue(ClaimTypes.Role);
            var perms  = user.FindAll("permissions").Select(c => c.Value).ToArray();
            return Ok(new { userId, name, role, permissions = perms });
        }
    }
}
