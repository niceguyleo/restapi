using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace JwtMvcDemo.Controllers
{
    [Authorize(Policy = "CanViewReport")]
    [ApiController]
    [Route("api/[controller]")]
    public class ReportsController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(new { report = "Top secret report data" });
        }
    }
}
