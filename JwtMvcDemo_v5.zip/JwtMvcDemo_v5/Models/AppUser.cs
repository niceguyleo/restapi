using System.ComponentModel.DataAnnotations;

namespace JwtMvcDemo.Models
{
    public class AppUser
    {
        [Key] public string Id { get; set; } = Guid.NewGuid().ToString("N");
        [Required, MaxLength(32)] public string UserName { get; set; } = default!;
        [Required, MaxLength(64)] public string Name { get; set; } = default!;
        [Required, MaxLength(256)] public string Password { get; set; } = default!; // Demo plain text
        [Required, MaxLength(32)] public string Role { get; set; } = "User";
        [MaxLength(256)] public string PermissionsCsv { get; set; } = "";
    }
}
