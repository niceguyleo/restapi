namespace JwtMvcDemo.Models
{
    public record LoginRequest(string UserName, string Password);
}
