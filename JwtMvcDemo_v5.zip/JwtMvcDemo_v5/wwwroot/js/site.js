const $ = (sel) => document.querySelector(sel);
const print = (v) => { $("#output").textContent = typeof v === "string" ? v : JSON.stringify(v, null, 2); };

const login = async () => {
  const userName = $("#username").value;
  const password = $("#password").value;
  const res = await fetch("/api/auth/login", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userName, password })
  });
  const data = await res.json();
  if (!res.ok) { $("#loginResult").textContent = "로그인 실패: " + (data?.message || res.status); return; }
  localStorage.setItem("accessToken", data.accessToken);
  $("#loginResult").textContent = "로그인 성공. 토큰 저장 완료."; print(data);
};

const callApi = async (url) => {
  const token = localStorage.getItem("accessToken");
  const res = await fetch(url, { headers: token ? { "Authorization": `Bearer ${token}` } : {} });
  const text = await res.text(); try { print(JSON.parse(text)); } catch { print(text); }
};
$("#btnLogin").addEventListener("click", login);
$("#btnMe").addEventListener("click", () => callApi("/api/users/me"));
$("#btnAdmin").addEventListener("click", () => callApi("/api/admin/dashboard"));
$("#btnReport").addEventListener("click", () => callApi("/api/reports"));
$("#btnClear").addEventListener("click", () => { localStorage.removeItem("accessToken"); $("#loginResult").textContent = "토큰 삭제됨"; });
