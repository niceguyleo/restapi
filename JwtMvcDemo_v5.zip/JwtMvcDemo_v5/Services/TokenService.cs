using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;

namespace JwtMvcDemo.Services
{
    public class TokenService : ITokenService
    {
        private readonly IConfiguration _config;
        public TokenService(IConfiguration config) => _config = config;

        public TokenPair CreateAccessToken(string subject, string name, string role, IEnumerable<string> permissions)
        {
            var jwt = _config.GetSection("Jwt");
            var issuer = jwt["Issuer"];
            var audience = jwt["Audience"];
            var minutes = int.Parse(jwt["AccessTokenMinutes"] ?? "60");
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt["Key"]!));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new List<Claim>
            {
                new Claim("sub", subject),
                new Claim(ClaimTypes.NameIdentifier, subject),
                new Claim(ClaimTypes.Name, name),
                new Claim(ClaimTypes.Role, role)
            };
            claims.AddRange(permissions.Select(p => new Claim("permissions", p)));

            var expires = DateTime.UtcNow.AddMinutes(minutes);

            var token = new JwtSecurityToken(
                issuer: issuer, audience: audience, claims: claims,
                notBefore: DateTime.UtcNow, expires: expires, signingCredentials: creds);
            var jwtString = new JwtSecurityTokenHandler().WriteToken(token);
            return new TokenPair(jwtString, expires);
        }
    }
}
