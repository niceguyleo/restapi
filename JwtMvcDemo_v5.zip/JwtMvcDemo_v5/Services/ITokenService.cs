namespace JwtMvcDemo.Services
{
    public interface ITokenService
    {
        TokenPair CreateAccessToken(string subject, string name, string role, IEnumerable<string> permissions);
    }
    public record TokenPair(string Token, DateTime ExpiresAt);
}
