# CalendarApiDemo (ASP.NET Core 8)

Simple ASP.NET Core Web API that returns calendar data and an MVC view that consumes it.

## Run

```bash
dotnet restore
dotnet run
```

Open:
- API:      http://localhost:5000/api/calendar?year=2025&month=8
- Web page: http://localhost:5000/
```

If HTTPS is enabled, use https://localhost:5001 accordingly.
