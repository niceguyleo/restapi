using Microsoft.AspNetCore.Mvc;

namespace CalendarApiDemo.Controllers;

public record CalendarResponse(
    int Year,
    int Month,
    DayOfWeek FirstDayOfWeek,
    List<List<int?>> Weeks
);

[ApiController]
[Route("api/[controller]")]
public class CalendarController : ControllerBase
{
    /// <summary>
    /// Returns a month calendar grid as 7-day weeks.
    /// Sunday=0 based on System.DayOfWeek.
    /// </summary>
    /// <example>GET /api/calendar?year=2025&month=8</example>
    [HttpGet]
    public ActionResult<CalendarResponse> Get([FromQuery] int year, [FromQuery] int month)
    {
        if (month < 1 || month > 12) return BadRequest("month must be 1..12");
        if (year < 1 || year > 9999) return BadRequest("year must be 1..9999");

        int first = (int)new DateOnly(year, month, 1).DayOfWeek; // Sunday=0..Saturday=6
        int dayInMonth = DateTime.DaysInMonth(year, month);

        var weeks = new List<List<int?>>();
        var week = new List<int?>();

        for (int i = 0; i < first; i++) week.Add(null); // pad before day 1

        for (int d = 1; d <= dayInMonth; d++)
        {
            week.Add(d);
            if (week.Count == 7)
            {
                weeks.Add(week);
                week = new List<int?>();
            }
        }

        if (week.Count > 0)
        {
            while (week.Count < 7) week.Add(null);
            weeks.Add(week);
        }

        var dto = new CalendarResponse(
            Year: year,
            Month: month,
            FirstDayOfWeek: (DayOfWeek)first,
            Weeks: weeks
        );

        return Ok(dto);
    }
}
