﻿const baseUrl = "/api/todos";
const resultEl = document.getElementById("result");

// 1. 모든 Todo 조회
async function getAllTodos() {
    const res = await fetch(baseUrl);
    const data = await res.json();
    resultEl.textContent = JSON.stringify(data, null, 2);
}

// 2. ID로 Todo 조회 (ID=1)
async function getTodoById() {
    const res = await fetch(`${baseUrl}/1`);
    if (res.status === 404) {
        resultEl.textContent = "Todo with ID=1 not found.";
        return;
    }
    const data = await res.json();
    resultEl.textContent = JSON.stringify(data, null, 2);
}

// 3. Todo 3개 생성 (하드코딩 데이터 사용)
const todosToCreate = [
    { author: "Alice", content: "Learn ASP.NET Core", createdAt: new Date().toISOString() },
    { author: "Bob", content: "Build a REST API", createdAt: new Date().toISOString() },
    { author: "Charlie", content: "Write documentation", createdAt: new Date().toISOString() }
];

async function createTodos() {
    for (const todo of todosToCreate) {
        const res = await fetch(baseUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(todo)
        });

        if (!res.ok) {
            const errorText = await res.text();
            resultEl.textContent = `Error creating todo: ${errorText}`;
            return;
        }
    }
    resultEl.textContent = "3 Todos created successfully!";
}

// 4. ID=1 Todo 수정 (예: content 변경)
async function updateTodo() {
    const updatedTodo = {
        id: 1,
        author: "Alice",
        content: "Learn ASP.NET Core - updated",
        createdAt: new Date().toISOString()
    };

    const res = await fetch(`${baseUrl}/1`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedTodo)
    });

    if (res.ok) {
        resultEl.textContent = "Todo with ID=1 updated successfully!";
    } else if (res.status === 404) {
        resultEl.textContent = "Todo with ID=1 not found.";
    } else {
        const errorText = await res.text();
        resultEl.textContent = `Error updating todo: ${errorText}`;
    }
}

// 5. ID=1 Todo 삭제
async function deleteTodo() {
    const res = await fetch(`${baseUrl}/1`, {
        method: "DELETE"
    });

    if (res.ok) {
        resultEl.textContent = "Todo with ID=1 deleted successfully!";
    } else if (res.status === 404) {
        resultEl.textContent = "Todo with ID=1 not found.";
    } else {
        const errorText = await res.text();
        resultEl.textContent = `Error deleting todo: ${errorText}`;
    }
}

// 버튼 이벤트 연결
document.getElementById("btnGetAll").addEventListener("click", getAllTodos);
document.getElementById("btnGetById").addEventListener("click", getTodoById);
document.getElementById("btnCreate").addEventListener("click", createTodos);
document.getElementById("btnUpdate").addEventListener("click", updateTodo);
document.getElementById("btnDelete").addEventListener("click", deleteTodo);
